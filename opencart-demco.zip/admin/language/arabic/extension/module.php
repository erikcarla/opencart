<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']    = 'الموديولات';

// Text
$_['text_install']     = 'تنصيب';
$_['text_uninstall']   = 'ازالة التنصيب';

// Column
$_['column_name']      = 'اسم الموديول';
$_['column_action']    = 'تحرير';

// Error
$_['error_permission'] = 'تحذير : أنت لا تمتلك صلاحيات التعديل!';
?>