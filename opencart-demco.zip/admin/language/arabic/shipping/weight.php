<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']    = 'الشحن بالوزن حسب المنطقة الجغرافية';

// Text
$_['text_shipping']    = 'الشحن';
$_['text_success']     = 'تم التعديل !';

// Entry
$_['entry_rate']       = 'سعر الوزن :<br /><span class="help">مثال: 5:10.00,7:12.00 الوزن:السعر,الوزن:السعر, إلخ..</span>';
$_['entry_tax']        = 'نوع الضريبة :<br /><span class="help">يفضل اختيار لايوجد</span>';
$_['entry_geo_zone']   = 'المنطقة الجغرافية :';
$_['entry_status']     = 'الحالة :';
$_['entry_sort_order'] = 'ترتيب الفرز :';

// Error
$_['error_permission'] = 'تحذير : أنت لا تمتلك صلاحيات التعديل !';
?>