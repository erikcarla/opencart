<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title'] = 'تقرير الأخطاء';

// Text
$_['text_success']  = 'تم تنظيف ملف تقرير الأخطاء !';
?>