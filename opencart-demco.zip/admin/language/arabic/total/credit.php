<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']    = 'رصيد العميل';

// Text
$_['text_total']       = 'اجماليات الطلب';
$_['text_success']     = 'تم التعديل!';

// Entry
$_['entry_status']     = 'الحالة:';
$_['entry_sort_order'] = 'ترتيب الفرز:';

// Error
$_['error_permission'] = 'تحذير: أنت لا تمتلك صلاحيات التعديل!';
?>