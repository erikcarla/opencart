<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']    = 'رسوم الشحن';

// Text
$_['text_total']       = 'اجماليات الطلب';
$_['text_success']     = 'تم التعديل!';

// Entry
$_['entry_total']      = 'إجمالي الطلب:';
$_['entry_fee']        = 'الرسوم:';
$_['entry_tax']        = 'نوع الضريبة:';
$_['entry_status']     = 'الحالة:';
$_['entry_sort_order'] = 'ترتيب الفرز:';

// Error
$_['error_permission'] = 'تحذير: أنت لا تمتلك صلاحيات التعديل!';
?>