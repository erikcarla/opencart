<?php

$_['lang_title'] = 'OpenBay Pro for Amazon US';
$_['lang_heading'] = 'Amazon US Overview';
$_['lang_overview'] = 'Amazon US Overview';
$_['lang_openbay'] = 'OpenBay Pro';
$_['lang_heading_settings'] = 'Settings';
$_['lang_heading_account'] = 'My Account';
$_['lang_heading_links'] = 'Item links';
$_['lang_heading_register'] = 'Register';
$_['lang_heading_bulk_listing'] = 'Bulk Listing';
$_['lang_heading_stock_updates'] = 'Stock updates';
$_['lang_heading_saved_listings'] = 'Saved listings';
$_['lang_heading_bulk_linking'] = 'Bulk Linking';
?>