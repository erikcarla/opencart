<?php
//Heading
$_['heading_title']         = 'eBay';

//Install actions
$_['text_install']          = 'Install';
$_['text_edit']             = 'Edit';
$_['text_uninstall']        = 'Uninstall';

//Status
$_['text_enabled']          = 'Enabled';
$_['text_disabled']         = 'Disabled';

//Messages
$_['error_category_nosuggestions']      = 'Could not load any suggested categories';
$_['lang_text_success']                 = 'You have saved your changes to the eBay extension';
$_['lang_error_retry']          		= 'Could not connect to the OpenBay server. ';
?>